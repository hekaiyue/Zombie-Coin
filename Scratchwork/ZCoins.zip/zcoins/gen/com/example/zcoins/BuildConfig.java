/** Automatically generated file. DO NOT MODIFY */
package com.example.zcoins;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}